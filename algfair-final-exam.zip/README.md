Final work for the spring 2024 course "Algorithmic Fairness and Ethics" 


Make an environment with "pip install -r requirements.txt"

Data exploration notebook is ["Data_investigation.ipynb"](notebooks/Data_investigation.ipynb)
Data Modeling is ["bayes_regression.ipynb"](notebooks/bayes_regression.ipynb)


Work done by Oleg Jarma Montoya and Philip Winstrøm-Jespersen